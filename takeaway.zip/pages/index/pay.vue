<template>
	<view style="display: auto;justify-content: center;margin: 0;">
		<img src="https://img2.baidu.com/it/u=3395582942,4228440123&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1660669200&t=d93027bfcec4190e624343564722b794" alt="" style="width: 400rpx;height:100% ;margin-top:30%;margin-left:23%;">
		<!-- <image src="https://img2.baidu.com/it/u=3395582942,4228440123&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1660669200&t=d93027bfcec4190e624343564722b794" mode=""style="width: 400rpx;height:100% ;margin-top:30%;margin-left:23%;"></image> -->
	</view>

</template>

<script>
</script>

<style>
</style>
