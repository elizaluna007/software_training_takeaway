<script>
	export default {
		data() {
			return {
			
			}
		},
		globalData: {
			// 测试代码
			// token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjMuMDAwMTExMTEyNzcxNjgzM2UrMTgsImlhdCI6MTY2MDU3MjEzOC4xMTIwMTI5LCJpc3MiOiJCYmJhY2siLCJkYXRhIjp7ImFjY291bnQiOiIzNDIxIiwicGFzc3dvcmQiOiIxMjM0NTYiLCJ0aW1lc3RhbXAiOjE2NjA1NzIxMzguMTEyMDEyOX19.i_R4lyy8IeXiTdjV75rtphU3tyAwDkspppPxKuZJG0o',
			// login_key: true
			//正式版本
			token: '',
			login_key: ''
		},
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
